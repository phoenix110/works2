create function newid() returns uuid
LANGUAGE SQL
AS $$
select md5(random()::text || clock_timestamp()::text)::uuid
$$;
